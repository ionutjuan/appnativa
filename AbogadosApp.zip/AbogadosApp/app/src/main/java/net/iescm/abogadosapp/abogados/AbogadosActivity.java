package net.iescm.abogadosapp.abogados;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import net.iescm.abogadosapp.R;

public class AbogadosActivity extends AppCompatActivity {

    public static final String EXTRA_ABOGADO_ID = "extra_abogado_id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abogados);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        AbogadosFragment fragment = (AbogadosFragment)
                getSupportFragmentManager().findFragmentById(R.id.abogados_container);

        if(fragment==null){
            fragment = AbogadosFragment.newInstance();
            getSupportFragmentManager()
                    .beginTransaction()
                    .add(R.id.abogados_container, fragment)
                    .commit();
        }
    }
}

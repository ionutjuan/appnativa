package net.iescm.abogadosapp.addeditabogado;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import net.iescm.abogadosapp.R;
import net.iescm.abogadosapp.abogados.AbogadosActivity;

public class AddEditAbogadoActivity extends AppCompatActivity {

    public static final int REQUEST_ADD_ABOGADO = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_abogado);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        String abogadoId = getIntent().getStringExtra(AbogadosActivity.EXTRA_ABOGADO_ID);

        setTitle(abogadoId == null ? "Añadir abogado" : "Editar abogado");

        AddEditAbogadoFragment addEditAbogadoFragment = (AddEditAbogadoFragment)
                getSupportFragmentManager().findFragmentById(R.id.add_edit_abogado_container);
        if (addEditAbogadoFragment == null) {
            addEditAbogadoFragment = AddEditAbogadoFragment.newInstance(abogadoId);
            getSupportFragmentManager()
                    .beginTransaction()
                    .add(R.id.add_edit_abogado_container, addEditAbogadoFragment)
                    .commit();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}

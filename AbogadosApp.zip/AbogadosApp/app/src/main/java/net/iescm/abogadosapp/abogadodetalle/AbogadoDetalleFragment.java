package net.iescm.abogadosapp.abogadodetalle;


import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import net.iescm.abogadosapp.R;
import net.iescm.abogadosapp.abogados.AbogadosActivity;
import net.iescm.abogadosapp.abogados.AbogadosFragment;
import net.iescm.abogadosapp.addeditabogado.AddEditAbogadoActivity;
import net.iescm.abogadosapp.data.Abogado;
import net.iescm.abogadosapp.data.AbogadosDbHelper;

/**
 * Vista para el detalle del abogado
 */
public class AbogadoDetalleFragment extends Fragment {
    private static final String ARG_ABOGADO_ID = "abogadoId";

    private String mAbogadoId;

    private CollapsingToolbarLayout mCollapsingView;
    private ImageView mAvatar;
    private TextView mPhoneNumber;
    private TextView mSpecialty;
    private TextView mBio;

    private AbogadosDbHelper mAbogadosDbHelper;

    public static AbogadoDetalleFragment newInstance(String abogadoId) {
        AbogadoDetalleFragment fragment = new AbogadoDetalleFragment();
        Bundle args = new Bundle();
        args.putString(ARG_ABOGADO_ID, abogadoId);
        fragment.setArguments(args);
        return fragment;
    }

    public AbogadoDetalleFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mAbogadoId = getArguments().getString(ARG_ABOGADO_ID);
        }
        setHasOptionsMenu(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_edit:
                showEditScreen();
                break;
            case R.id.action_delete:
                new DeleteAbogadoTask().execute();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_abogado_detalle, container, false);
        mCollapsingView = (CollapsingToolbarLayout) getActivity().findViewById(R.id.toolbar_layout);
        mAvatar = (ImageView) getActivity().findViewById(R.id.iv_avatar);
        mPhoneNumber = (TextView) root.findViewById(R.id.tv_phone_number);
        mSpecialty = (TextView) root.findViewById(R.id.tv_specialty);
        mBio = (TextView) root.findViewById(R.id.tv_bio);

        mAbogadosDbHelper = new AbogadosDbHelper(getActivity());

        loadAbogado();

        return root;
    }

    private void loadAbogado() {
        new GetAbogadoByIdTask().execute();
    }

    private class GetAbogadoByIdTask extends AsyncTask<Void, Void, Cursor> {

        @Override
        protected Cursor doInBackground(Void... voids) {
            return mAbogadosDbHelper.getAbogadoById(mAbogadoId);
        }

        @Override
        protected void onPostExecute(Cursor cursor) {
            if (cursor != null && cursor.moveToLast()) {
                showAbogado(new Abogado(cursor));
            } else {
                showLoadError();
            }
        }

    }

    private void showAbogado(Abogado abogado) {
        mCollapsingView.setTitle(abogado.getName());
        Glide.with(this)
                .load(Uri.parse("file:///android_asset/" + abogado.getAvatarUri()))
                .centerCrop()
                .into(mAvatar);
        mPhoneNumber.setText(abogado.getPhoneNumber());
        mSpecialty.setText(abogado.getSpecialty());
        mBio.setText(abogado.getBio());
    }

    private void showEditScreen() {
        Intent intent = new Intent(getActivity(), AddEditAbogadoActivity.class);
        intent.putExtra(AbogadosActivity.EXTRA_ABOGADO_ID, mAbogadoId);
        startActivityForResult(intent, AbogadosFragment.REQUEST_UPDATE_DELETE_ABOGADO);
    }

    private void showLoadError() {
        Toast.makeText(getActivity(),
                "Error al cargar información", Toast.LENGTH_SHORT).show();
    }

    private void showDeleteError() {
        Toast.makeText(getActivity(),
                "Error al eliminar abogado", Toast.LENGTH_SHORT).show();
    }

    private void showAbogadosScreen(boolean requery) {
        if (!requery) {
            showDeleteError();
        }
        getActivity().setResult(requery ? Activity.RESULT_OK : Activity.RESULT_CANCELED);
        getActivity().finish();
    }

    private class DeleteAbogadoTask extends AsyncTask<Void, Void, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {
            return mAbogadosDbHelper.deleteAbogado(mAbogadoId);
        }

        @Override
        protected void onPostExecute(Integer integer) {
            showAbogadosScreen(integer > 0);
        }

    }

}

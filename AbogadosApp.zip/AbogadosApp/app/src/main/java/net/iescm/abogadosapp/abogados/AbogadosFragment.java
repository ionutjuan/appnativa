package net.iescm.abogadosapp.abogados;


import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import net.iescm.abogadosapp.R;
import net.iescm.abogadosapp.abogadodetalle.AbogadoDetalleActivity;
import net.iescm.abogadosapp.addeditabogado.AddEditAbogadoActivity;
import net.iescm.abogadosapp.data.AbogadosDbHelper;

import static net.iescm.abogadosapp.data.AbogadosContract.AbogadoEntry;

/**
 * Vista para la lista de abogados del gabinete
 */
public class AbogadosFragment extends Fragment {
    public static final int REQUEST_UPDATE_DELETE_ABOGADO = 2;

    private AbogadosDbHelper mAbogadosDbHelper;

    private ListView mAbogadosList;
    private AbogadosCursorAdapter mAbogadosAdapter;
    private FloatingActionButton mAddButton;


    public AbogadosFragment() {
        // Required empty public constructor
    }

    public static AbogadosFragment newInstance() {
        return new AbogadosFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_abogados, container, false);

        // Referencias UI
        mAbogadosList = (ListView) root.findViewById(R.id.Abogados_list);
        mAbogadosAdapter = new AbogadosCursorAdapter(getActivity(), null);
        mAddButton = (FloatingActionButton) getActivity().findViewById(R.id.fab);

        // Setup
        mAbogadosList.setAdapter(mAbogadosAdapter);

        // Eventos
        mAbogadosList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Cursor currentItem = (Cursor) mAbogadosAdapter.getItem(i);
                String currentAbogadoId = currentItem.getString(
                        currentItem.getColumnIndex(AbogadoEntry.ID));

                showDetailScreen(currentAbogadoId);
            }
        });

        mAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAddScreen();
            }
        });

        // Borrado de la DB para su recreación
        //getActivity().deleteDatabase(AbogadosDbHelper.DATABASE_NAME);

        // Instancia de helper
        mAbogadosDbHelper = new AbogadosDbHelper(getActivity());

        // Carga de datos
        loadAbogados();

        return root;
    }

    private void loadAbogados() {
        // Cargar datos...
        new AbogadosLoadTask().execute();
    }

    private void showAddScreen() {
        Intent intent = new Intent(getActivity(), AddEditAbogadoActivity.class);
        startActivityForResult(intent, AddEditAbogadoActivity.REQUEST_ADD_ABOGADO);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (Activity.RESULT_OK == resultCode) {
            switch (requestCode) {
                case AddEditAbogadoActivity.REQUEST_ADD_ABOGADO:
                    showSuccessfullSavedMessage();
                    loadAbogados();
                    break;
                case REQUEST_UPDATE_DELETE_ABOGADO:
                    loadAbogados();
                    break;
            }
        }
    }

    private void showSuccessfullSavedMessage() {
        Toast.makeText(getActivity(),
                "Abogado guardado correctamente", Toast.LENGTH_SHORT).show();
    }

    private void showDetailScreen(String abogadoId) {
        Intent intent = new Intent(getActivity(), AbogadoDetalleActivity.class);
        intent.putExtra(AbogadosActivity.EXTRA_ABOGADO_ID, abogadoId);
        startActivityForResult(intent, REQUEST_UPDATE_DELETE_ABOGADO);
    }

    private class AbogadosLoadTask extends AsyncTask<Void, Void, Cursor> {

        @Override
        protected Cursor doInBackground(Void... voids) {
            return mAbogadosDbHelper.getAllAbogados();
        }

        @Override
        protected void onPostExecute(Cursor cursor) {
            if (cursor != null && cursor.getCount() > 0) {
                mAbogadosAdapter.swapCursor(cursor);
            } else {
                // Mostrar empty state
            }
        }
    }

}

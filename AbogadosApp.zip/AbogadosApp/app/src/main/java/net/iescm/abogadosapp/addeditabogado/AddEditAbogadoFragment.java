package net.iescm.abogadosapp.addeditabogado;


import android.app.Activity;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import net.iescm.abogadosapp.R;
import net.iescm.abogadosapp.data.Abogado;
import net.iescm.abogadosapp.data.AbogadosDbHelper;

/**
 * Vista para creación/edición de un abogado
 */
public class AddEditAbogadoFragment extends Fragment {
    private static final String ARG_ABOGADO_ID = "arg_Abogado _id";

    private String mAbogadoId;

    private AbogadosDbHelper mAbogadosDbHelper;

    private FloatingActionButton mSaveButton;
    private TextInputEditText mNameField;
    private TextInputEditText mPhoneNumberField;
    private TextInputEditText mSpecialtyField;
    private TextInputEditText mBioField;
    private TextInputLayout mNameLabel;
    private TextInputLayout mPhoneNumberLabel;
    private TextInputLayout mSpecialtyLabel;
    private TextInputLayout mBioLabel;

    public AddEditAbogadoFragment() {
        // Required empty public constructor
    }

    public static AddEditAbogadoFragment newInstance(String abogadoId) {
        AddEditAbogadoFragment fragment = new AddEditAbogadoFragment();
        Bundle args = new Bundle();
        args.putString(ARG_ABOGADO_ID, abogadoId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mAbogadoId = getArguments().getString(ARG_ABOGADO_ID);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_add_edit_abogado, container, false);

        // Referencias UI
        mSaveButton = (FloatingActionButton) getActivity().findViewById(R.id.fab);
        mNameField = (TextInputEditText) root.findViewById(R.id.et_name);
        mPhoneNumberField = (TextInputEditText) root.findViewById(R.id.et_phone_number);
        mSpecialtyField = (TextInputEditText) root.findViewById(R.id.et_specialty);
        mBioField = (TextInputEditText) root.findViewById(R.id.et_bio);
        mNameLabel = (TextInputLayout) root.findViewById(R.id.til_name);
        mPhoneNumberLabel = (TextInputLayout) root.findViewById(R.id.til_phone_number);
        mSpecialtyLabel = (TextInputLayout) root.findViewById(R.id.til_specialty);
        mBioLabel = (TextInputLayout) root.findViewById(R.id.til_bio);

        // Eventos
        mSaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addEditAbogado();
            }
        });

        mAbogadosDbHelper = new AbogadosDbHelper(getActivity());

        // Carga de datos
        if (mAbogadoId != null) {
            loadAbogado();
        }

        return root;
    }

    private void loadAbogado() {
        // AsyncTask
        new GetAbogadoByIdTask().execute();
    }

    private void addEditAbogado() {
        boolean error = false;

        String name = mNameField.getText().toString();
        String phoneNumber = mPhoneNumberField.getText().toString();
        String specialty = mSpecialtyField.getText().toString();
        String bio = mBioField.getText().toString();

        if (TextUtils.isEmpty(name)) {
            mNameLabel.setError(getString(R.string.field_error));
            error = true;
        }

        if (TextUtils.isEmpty(phoneNumber)) {
            mPhoneNumberLabel.setError(getString(R.string.field_error));
            error = true;
        }

        if (TextUtils.isEmpty(specialty)) {
            mSpecialtyLabel.setError(getString(R.string.field_error));
            error = true;
        }


        if (TextUtils.isEmpty(bio)) {
            mBioLabel.setError(getString(R.string.field_error));
            error = true;
        }

        if (error) {
            return;
        }

        Abogado abogado = new Abogado(name, specialty, phoneNumber, bio, "");

        new AddEditAbogadoTask().execute(abogado);

    }

    private void showAbogadosScreen(Boolean requery) {
        if (!requery) {
            showAddEditError();
            getActivity().setResult(Activity.RESULT_CANCELED);
        } else {
            getActivity().setResult(Activity.RESULT_OK);
        }

        getActivity().finish();
    }

    private void showAddEditError() {
        Toast.makeText(getActivity(),
                "Error al agregar nueva información", Toast.LENGTH_SHORT).show();
    }

    private void showAbogado(Abogado abogado) {
        mNameField.setText(abogado.getName());
        mPhoneNumberField.setText(abogado.getPhoneNumber());
        mSpecialtyField.setText(abogado.getSpecialty());
        mBioField.setText(abogado.getBio());
    }

    private void showLoadError() {
        Toast.makeText(getActivity(),
                "Error al editar abogado", Toast.LENGTH_SHORT).show();
    }

    private class GetAbogadoByIdTask extends AsyncTask<Void, Void, Cursor> {

        @Override
        protected Cursor doInBackground(Void... voids) {
            return mAbogadosDbHelper.getAbogadoById(mAbogadoId);
        }

        @Override
        protected void onPostExecute(Cursor cursor) {
            if (cursor != null && cursor.moveToLast()) {
                showAbogado(new Abogado(cursor));
            } else {
                showLoadError();
                getActivity().setResult(Activity.RESULT_CANCELED);
                getActivity().finish();
            }
        }

    }

    private class AddEditAbogadoTask extends AsyncTask<Abogado, Void, Boolean> {

        @Override
        protected Boolean doInBackground(Abogado... abogados) {
            if (mAbogadoId != null) {
                return mAbogadosDbHelper.updateAbogado(abogados[0], mAbogadoId) > 0;

            } else {
                return mAbogadosDbHelper.saveAbogado(abogados[0]) > 0;
            }

        }

        @Override
        protected void onPostExecute(Boolean result) {
            showAbogadosScreen(result);
        }

    }

}
